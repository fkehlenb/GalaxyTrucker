package com.galaxytrucker.galaxytruckerreloaded.Model.ShipLayout;

public enum SystemType {
    ENGINE, O2, WEAPON_SYSTEM,MEDBAY,SHIELDS,CAMERAS,COCKPIT
}
