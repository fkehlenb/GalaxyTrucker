package com.galaxytrucker.galaxytruckerreloaded.Model.Crew;

/** Crew stat to upgrade */
public enum CrewStat {
    WEAPON, SHIELD, ENGINE, REAPAIR, COMBAT
}
