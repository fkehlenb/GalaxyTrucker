package com.galaxytrucker.galaxytruckerreloaded.Model.Weapons;

public enum WeaponType {
    LASER,ROCKET,RADIO,BOMB,RADIO_BOMB
}
