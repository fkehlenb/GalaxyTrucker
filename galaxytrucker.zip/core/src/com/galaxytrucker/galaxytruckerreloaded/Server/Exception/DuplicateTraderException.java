package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the trader already exists */
public class DuplicateTraderException extends Exception {
}
