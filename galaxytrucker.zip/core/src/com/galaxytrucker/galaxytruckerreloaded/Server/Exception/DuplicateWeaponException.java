package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the weapon already exists */
public class DuplicateWeaponException extends Exception {
}
