package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the response object already exists */
public class DuplicateResponseObjectException extends Exception {
}
