package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the request object already exists */
public class DuplicateRequestObjectException extends Exception {
}
