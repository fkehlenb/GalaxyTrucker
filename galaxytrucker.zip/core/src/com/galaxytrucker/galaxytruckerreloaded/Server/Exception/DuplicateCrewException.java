package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the crew object already exists */
public class DuplicateCrewException extends Exception {
}
