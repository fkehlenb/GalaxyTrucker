package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the planet object already exists */
public class DuplicatePlanetException extends Exception {
}
