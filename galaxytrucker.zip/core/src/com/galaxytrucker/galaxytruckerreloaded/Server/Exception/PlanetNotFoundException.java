package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a planet cannot be found */
public class PlanetNotFoundException extends Exception {
}
