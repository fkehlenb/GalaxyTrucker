package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the user already exists */
public class DuplicateUserException extends Exception {
}
