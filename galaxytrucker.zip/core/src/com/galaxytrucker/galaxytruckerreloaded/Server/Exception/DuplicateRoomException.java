package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the room object already exists */
public class DuplicateRoomException extends Exception {
}
