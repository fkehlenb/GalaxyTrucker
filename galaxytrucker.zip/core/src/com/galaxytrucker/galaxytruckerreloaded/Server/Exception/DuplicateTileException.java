package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the tile object already exists */
public class DuplicateTileException extends Exception {
}
