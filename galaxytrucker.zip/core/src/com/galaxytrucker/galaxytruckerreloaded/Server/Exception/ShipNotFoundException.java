package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a ship cannot be found */
public class ShipNotFoundException extends Exception {
}
