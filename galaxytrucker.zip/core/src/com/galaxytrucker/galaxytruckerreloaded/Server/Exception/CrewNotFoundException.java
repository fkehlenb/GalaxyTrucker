package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when no crew can be found */
public class CrewNotFoundException extends Exception {
}
