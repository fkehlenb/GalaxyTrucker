package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a weapon cannot be found */
public class WeaponNotFoundException extends Exception {
}
