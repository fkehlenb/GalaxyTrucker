package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a request object cannot be found */
public class RequestObjectNotFoundException extends Exception {
}
