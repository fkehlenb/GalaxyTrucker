package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a response object cannot be found */
public class ResponseObjectNotFoundException extends Exception {
}
