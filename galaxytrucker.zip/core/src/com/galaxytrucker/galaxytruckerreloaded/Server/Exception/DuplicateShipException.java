package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the ship object already exists */
public class DuplicateShipException extends Exception {
}
