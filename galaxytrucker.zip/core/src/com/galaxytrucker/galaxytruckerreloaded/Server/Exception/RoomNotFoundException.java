package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a room cannot be found */
public class RoomNotFoundException extends Exception {
}
