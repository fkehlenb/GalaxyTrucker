package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a user cannot be found */
public class UserNotFoundException extends Exception {
}
