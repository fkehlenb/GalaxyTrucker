package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a tile cannot be found */
public class TileNotFoundException extends Exception {
}
