package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when a trader cannot be found */
public class TraderNotFoundException extends Exception {
}
