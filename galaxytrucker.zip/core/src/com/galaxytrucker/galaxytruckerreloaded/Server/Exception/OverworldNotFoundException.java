package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the overWorld cannot be found */
public class OverworldNotFoundException extends Exception {
}
