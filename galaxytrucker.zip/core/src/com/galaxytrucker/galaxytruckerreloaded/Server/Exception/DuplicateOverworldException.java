package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

/** Thrown when the overWorld object already exists */
public class DuplicateOverworldException extends Exception {
}
