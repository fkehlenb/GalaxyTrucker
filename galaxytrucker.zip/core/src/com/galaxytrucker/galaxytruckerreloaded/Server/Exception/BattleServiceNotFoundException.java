package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class BattleServiceNotFoundException extends Exception {
}
