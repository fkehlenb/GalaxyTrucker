package com.galaxytrucker.galaxytruckerreloaded.Server.Opponent;

public enum TargetMode {
    CREW,ENGINE, O2, WEAPON_SYSTEM,MEDBAY,SHIELDS,CAMERAS,COCKPIT, ROOM
}
