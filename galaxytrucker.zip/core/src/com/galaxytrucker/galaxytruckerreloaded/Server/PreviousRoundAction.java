package com.galaxytrucker.galaxytruckerreloaded.Server;

public enum PreviousRoundAction {
    MOVE_CREW,FLEE_FIGHT,ATTACK_SHIP,HEAL_SHIP,OPPONENT_DEAD,YOU_DEAD,HEAL_CREW,HEAL_CREW_IN_ROOM, CREW_DEAD, CREW_MOVED
}
