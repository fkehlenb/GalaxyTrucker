package com.galaxytrucker.galaxytruckerreloaded.View.Buttons.ShopButtons;

public enum ShopButtonType {
    WEAPON,RESOURCE,CREW,SYSTEM,UPGRADES,SELL
}
