package com.galaxytrucker.galaxytruckerreloaded.View.UI.Events.Shop;

public enum ShopElementType {
    WEAPON,HP,FUEL,MISSILES,CREW,SYSTEM,UPGRADES,CREWUPGRADES
}
