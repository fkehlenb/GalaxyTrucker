package com.galaxytrucker.galaxytruckerreloaded.Controller;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor(access = AccessLevel.PUBLIC)
public class HangerController extends Controller {


    /**
     * Picks a Shipmodel
     * @param username - the specified username
     */
    public void pickShip(String username){
    }
}
