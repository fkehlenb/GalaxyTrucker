package com.galaxytrucker.galaxytruckerreloaded.Model.Map;

public enum PlanetEvent {
    COMBAT,VOID,SHOP,BOSS,MINIBOSS,NEBULA,METEORSHOWER,PVP
}
