package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class TraderNotFoundException extends Exception {
}
