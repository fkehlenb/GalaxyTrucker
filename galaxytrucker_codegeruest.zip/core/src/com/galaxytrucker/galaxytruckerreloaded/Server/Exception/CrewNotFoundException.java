package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class CrewNotFoundException extends Exception {
}
