package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateOverworldException extends Exception {
}
