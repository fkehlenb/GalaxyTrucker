package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class PlanetNotFoundException extends Exception {
}
