package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateTraderException extends Exception {
}
