package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicatePlanetException extends Exception {
}
