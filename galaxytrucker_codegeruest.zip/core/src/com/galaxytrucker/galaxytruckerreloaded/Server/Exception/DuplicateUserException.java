package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateUserException extends Exception {
}
