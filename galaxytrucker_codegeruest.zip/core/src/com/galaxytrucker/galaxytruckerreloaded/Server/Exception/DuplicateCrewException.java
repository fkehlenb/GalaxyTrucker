package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateCrewException extends Exception {
}
