package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateShipException extends Exception {
}
