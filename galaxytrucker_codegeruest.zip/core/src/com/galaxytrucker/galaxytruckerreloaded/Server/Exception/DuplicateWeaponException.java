package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateWeaponException extends Exception {
}
