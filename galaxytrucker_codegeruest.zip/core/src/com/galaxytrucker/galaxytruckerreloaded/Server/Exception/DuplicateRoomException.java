package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class DuplicateRoomException extends Exception {
}
