package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class UserNotFoundException extends Exception {
}
