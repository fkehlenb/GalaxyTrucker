package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class ShipNotFoundException extends Exception {
}
