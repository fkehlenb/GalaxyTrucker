package com.galaxytrucker.galaxytruckerreloaded.Server.Exception;

public class OverworldNotFoundException extends Exception {
}
