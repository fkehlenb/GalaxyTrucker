package com.galaxytrucker.galaxytruckerreloaded.View.UI.EnemyShipInfo;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.List;
import com.galaxytrucker.galaxytruckerreloaded.Main;

public class EnemyHullUI {

    /**
     * SpriteBatch
     */
    private SpriteBatch batch;

    /**
     * Orthographic camera
     */
    private OrthographicCamera camera;

    /**
     * the texture for the background
     */
    private Texture HullBackground;

    /**
     * the textures to display the current status of the hull
     */
    private List<Texture> hullStatusTextures;


    /**
     * the status needs to be updated
     * @param status the new status
     */
    public void hullStatusUpdate(int status) {

    }

    /**
     * Setup called after initialisation
     */
    private void setup() {
    }

    /**
     * show the enemy hull ui
     */
    public void showEnemyHullUI() {

    }

    /**
     * hide the enemy hull ui
     */
    public void hideEnemyHullUI() {

    }

    /**
     * dispose of the enemy hull UI
     */
    public void disposeEnemyHullUI() {

    }

    /**
     * constructor
     * @param main the main class
     */
    public EnemyHullUI(Main main) {

    }
}
