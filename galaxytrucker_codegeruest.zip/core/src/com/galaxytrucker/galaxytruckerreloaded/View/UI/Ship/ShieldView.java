package com.galaxytrucker.galaxytruckerreloaded.View.UI.Ship;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class ShieldView {

    /** SpriteBatch */
    private SpriteBatch batch;

    /** Orthographic camera */
    private OrthographicCamera camera;
}
